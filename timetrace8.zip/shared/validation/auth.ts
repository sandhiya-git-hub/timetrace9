export type RegistrationField = 'name' | 'username' | 'email' | 'password' | 'confirmPassword';

export type FieldErrors = Partial<Record<RegistrationField, string>>;

export interface PasswordRule {
  id: string;
  label: string;
  test: (password: string) => boolean;
}

export const PASSWORD_RULES: PasswordRule[] = [
  { id: 'length', label: 'At least 8 characters', test: (p: string) => (p || '').length >= 8 },
  { id: 'uppercase', label: 'One uppercase letter', test: (p: string) => /[A-Z]/.test(p || '') },
  { id: 'lowercase', label: 'One lowercase letter', test: (p: string) => /[a-z]/.test(p || '') },
  { id: 'number', label: 'One number', test: (p: string) => /[0-9]/.test(p || '') },
  { id: 'special', label: 'One special character', test: (p: string) => /[^A-Za-z0-9]/.test(p || '') },
];

export const normalizeName = (name: unknown): string => {
  return String(name ?? '').trim().replace(/\s+/g, ' ');
};

export const normalizeUsername = (username: unknown): string => {
  return String(username ?? '').trim().toLowerCase();
};

export const normalizeEmail = (email: unknown): string => {
  return String(email ?? '').trim().toLowerCase();
};

export const validateName = (name: unknown): string | null => {
  if (name === null || name === undefined) return 'Full name is required.';
  const val = String(name).trim();
  if (val.length === 0) return 'Full name is required.';
  if (val.length < 2) return 'Full name must be at least 2 characters.';
  if (val.length > 60) return 'Full name must be 60 characters or fewer.';
  // Accepts real names with letters, accents, spaces, apostrophes, hyphens and periods.
  // Rejects digits, HTML tags, leading/trailing hyphens.
  const nameRegex = /^[\p{L}][\p{L}\s.'-]*[\p{L}.]$/u;
  if (!nameRegex.test(val)) {
    return 'Full name can only contain letters, spaces, hyphens, periods, and apostrophes.';
  }
  return null;
};

export const validateUsername = (username: unknown): string | null => {
  if (username === null || username === undefined) return 'Username is required.';
  const val = String(username).trim();
  if (val.length === 0) return 'Username is required.';
  if (val.length < 3 || val.length > 20) {
    return 'Username must be 3–20 characters.';
  }
  if (!/^[a-zA-Z0-9_]+$/.test(val)) {
    return 'Username can only contain letters, numbers and underscores.';
  }
  return null;
};

export const validateEmail = (email: unknown): string | null => {
  if (email === null || email === undefined) return 'Email address is required.';
  const val = String(email).trim();
  if (val.length === 0) return 'Email address is required.';
  // Standard strict email pattern requiring valid domain labels with at least one dot, no spaces or leading hyphens
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  if (!emailRegex.test(val)) {
    return 'Please enter a valid email address.';
  }
  return null;
};

export const validatePassword = (password: unknown): string | null => {
  if (password === null || password === undefined) return 'Password is required.';
  const val = String(password);
  if (val.length === 0) return 'Password is required.';
  if (val.length < 8) return 'Password must be at least 8 characters long.';
  if (new TextEncoder().encode(val).length > 72) {
    return 'Password must be 72 bytes or fewer.';
  }
  if (!/[A-Z]/.test(val)) return 'Password must include at least one uppercase letter.';
  if (!/[a-z]/.test(val)) return 'Password must include at least one lowercase letter.';
  if (!/[0-9]/.test(val)) return 'Password must include at least one number.';
  if (!/[^A-Za-z0-9]/.test(val)) return 'Password must include at least one special character.';
  return null;
};

export const validateConfirmPassword = (password: unknown, confirmPassword: unknown): string | null => {
  const confirm = String(confirmPassword ?? '');
  if (!confirm) return 'Please confirm your password.';
  if (confirm !== String(password ?? '')) return 'Passwords do not match.';
  return null;
};

export interface RegistrationValidationResult {
  valid: boolean;
  errors: FieldErrors;
  values: {
    name: string;
    username: string;
    email: string;
  };
}

export const validateRegistration = (form: Record<string, any> = {}): RegistrationValidationResult => {
  const errors: FieldErrors = {};
  const nameError = validateName(form.name);
  if (nameError) errors.name = nameError;

  const usernameError = validateUsername(form.username);
  if (usernameError) errors.username = usernameError;

  const emailError = validateEmail(form.email);
  if (emailError) errors.email = emailError;

  const passwordError = validatePassword(form.password);
  if (passwordError) errors.password = passwordError;

  const confirmError = validateConfirmPassword(form.password, form.confirmPassword);
  if (confirmError) errors.confirmPassword = confirmError;

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    values: {
      name: normalizeName(form.name),
      username: normalizeUsername(form.username),
      email: normalizeEmail(form.email),
    },
  };
};
