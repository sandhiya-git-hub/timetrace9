export type AppScreen = 'splash' | 'auth' | 'app';

export type PrimaryNavTab = 'dashboard' | 'timeline' | 'raw' | 'assistant';

export type CanonicalCategory =
  | 'Coding'
  | 'Work'
  | 'Study'
  | 'Research'
  | 'Entertainment'
  | 'Communication'
  | 'Productivity & Planning'
  | 'Utilities'
  | 'Idle'
  | 'Unclassified';

export type ActivityCategory =
  | CanonicalCategory
  | 'Deep Work'
  | 'Learning & Research'
  | 'Learning'
  | 'Utility / Admin'
  | 'Utility'
  | 'Distraction';

export type IntentLabel =
  | 'DEEP_WORK'
  | 'LEARNING'
  | 'COLLABORATION'
  | 'COMMUNICATION'
  | 'ADMIN'
  | 'DISTRACTION'
  | 'DISTRACTION_BREAK'
  | string;

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  name: string;
  givenName?: string;
  picture?: string;
  deviceToken: string;
  emailVerified?: boolean;
  lastLogin?: string;
  isRegistered?: boolean;
  hasConfiguredDevice?: boolean;
}

export interface DeviceState {
  connected: boolean;
  status:
    | 'CONNECTED'
    | 'CONNECTED_AWAITING_ACTIVITY'
    | 'RECONNECTING'
    | 'DISCONNECTED'
    | 'NOT_CONNECTED'
    | 'ERROR'
    | string;
  paused: boolean;
  deviceName: string;
  os: string;
  agentVersion: string;
  samplingInterval: string;
  lastEventTime: string | null;
  lastLocalDate: string;
  eventCount: number;
  statusText: string;
  lastPing?: string | null;
  lastHeartbeatAt?: string | null;
  connectedSince?: string | null;
  lastSuccessfulConnectionAt?: string | null;
  currentWindowTitle?: string | null;
  currentForegroundApp?: string | null;
}

export interface TelemetryEvent {
  id?: string;
  timestamp: string;
  date?: string;
  recorded_at?: string;
  app_name: string;
  window_title: string;
  category: string;
  dwell_ms: number;
  confidence?: number;
  classification_reason?: string;
  is_collector_process?: boolean;
  // Browser-level telemetry
  url?: string;
  domain?: string;
  page_title?: string;
  tab_id?: number | string;
  is_active_tab?: boolean;
  page_visible?: boolean;
  // Engagement detection (privacy-safe aggregated counters)
  scroll_count?: number;
  click_count?: number;
  key_count?: number;
  keys?: number;
  keyboard_events?: number;
  active_dwell_ms?: number;
  idle_dwell_ms?: number;
  engagement_state?: 'active' | 'passive' | 'idle' | 'engaged' | 'open_only' | 'background';
  interaction_rate?: number;
  sourceType?: string;
  revisited?: boolean;
  revisit_count?: number;
  intent?: IntentLabel;
  break_type?: 'intentional_break' | 'distraction_rabbit_hole' | 'micro_switch' | null;
}

export interface SubEvent {
  app: string;
  title: string;
  dwell_s: number;
  keys?: number;
  url?: string;
  domain?: string;
  active_dwell_s?: number;
  idle_dwell_s?: number;
  clicks?: number;
  scrolls?: number;
}

export interface ChunkSummary {
  chunk_id: string;
  recorded_at?: string;
  localDate?: string;
  duration_s: number;
  active_duration_s?: number;
  idle_duration_s?: number;
  start_time: string;
  end_time: string;
  closed_by?: string;
  main_events: SubEvent[];
  anchor_app: string;
  anchor_held_s?: number;
  returned_to_anchor?: boolean;
  // Browser context
  url?: string;
  domain?: string;
  // Engagement metrics
  engagement_score?: number; // 0 - 100
  engagement_state?: 'active' | 'passive' | 'idle' | 'engaged' | 'open_only' | 'background';
  interaction_summary?: string;
  scroll_count?: number;
  click_count?: number;
  key_count?: number;
  keyboard?: {
    total_keys: number;
    rate_per_min: number;
  };
  micro_behavior?: {
    total_rapid_switches: number;
    tab_flickers: number;
    avg_micro_dwell_ms: number;
    dominant_pattern: string;
    unique_micro_apps: string[];
  };
  categories_present?: string[];
  dominant_category?: string;
  copy_paste_events?: number;
  session_start_restless?: boolean;
  intent?: IntentLabel;
  confidence?: number;
  classification_reason?: string;
  is_collector_process?: boolean;
  primary_task?: string;
  distraction_detected?: boolean;
  distraction_type?: string | null;
  break_type?: 'intentional_break' | 'distraction_rabbit_hole' | 'micro_switch' | null;
  work_state?: string;
  unresolved_threads?: string[];
  summary?: string;
  user_corrected?: boolean;
  revisited?: boolean;
  revisit_count?: number;
}

export interface DailySynthesis {
  date: string;
  total_deep_work_s: number;
  total_distraction_s: number;
  pure_deep_work_s?: number;
  total_learning_s?: number;
  total_communication_s?: number;
  total_utility_s?: number;
  total_unclassified_s?: number;
  total_coding_s?: number;
  total_work_s?: number;
  total_study_s?: number;
  total_research_s?: number;
  total_entertainment_s?: number;
  total_comm_s?: number;
  total_productivity_planning_s?: number;
  total_utilities_s?: number;
  total_idle_s?: number;
  category_breakdown?: Record<string, number>;
  total_telemetry_s: number;
  total_active_dwell_s?: number;
  total_idle_dwell_s?: number;
  overall_engagement_score?: number; // 0 - 100
  fragmentation_score: number;
  peak_focus_window: string;
  context_switches: number;
  distraction_triggers: string[];
  daily_narrative: string;
  unfinished_work?: string[];
  work_state?: string;
  stat_sub?: {
    deep_work?: string;
    distraction?: string;
    context_switches?: string;
    work_state?: string;
  };
  range?: string;
  longest_session_s?: number;
  longest_session_app?: string;
  avg_dwell_per_switch_s?: number;
  top_app_today?: { name: string; dwell_s: number };
  tracked_days_count?: number;
  deep_work_ratio?: number;
  distraction_ratio?: number;
}

export interface ReentryBriefing {
  project?: string;
  found?: boolean;
  days_ago?: number;
  time_desc?: string;
  headline?: string;
  primary_task?: string;
  summary?: string;
  unresolved_threads?: string[];
  last_session?: ChunkSummary;
}

export interface ChatMessage {
  id?: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
  suggestedFollowUps?: string[];
}
